# Research Pipeline Progress Log

Auto-resume instructions: read this file and `git log`, then continue from the first unchecked item.
Package root: `Target_Journal_Submission/`. Code: `Target_Journal_Submission/code/`.

## Status (final, 2026-11-12)
- [x] Phase 0: target journal JKSU-CIS (Springer Nature); measured median received→accepted 66 d; JIF 6.4.
- [x] Phases 1–5: topic, literature matrix, novelty map, hypotheses (supplementary/research_design).
- [x] Phases 6–10: implementation, run_all.py, tests (18 passing).
- [x] Phases 11–20: all experiments complete (E1 16,308 runs; E2–E7, E4b); statistics, figures, tables generated.
- [x] Phases 21–42: manuscript (DOCX+PDF), Online Resources, title page, cover letter, 10 review rounds,
      consistency and reproducibility audits, rejection-risk report. Decision: READY FOR SUBMISSION
      (after the human authors complete the placeholders).

## Protocol decisions (pre-registered before confirmatory runs)
- UCR 2018: 113 complete datasets. A development set of 10 is used for design decisions: the 5 pilot datasets
  (ArrowHead, GunPoint, ECG200, Wafer, ShapesAll) plus 5 drawn at random with seed 2026 (CinCECGTorso, MoteStrain,
  MixedShapesSmallTrain, DistalPhalanxOutlineAgeGroup, MiddlePhalanxOutlineAgeGroup).
  The remaining 103 are confirmatory. The 15 natural-missing/variable-length datasets are used for external validation.
- Fixed UCR train/test splits. Missingness is simulated independently for train and test with deterministic, hashed seeds.

## Negative / iteration log (Phase 19)
1. Pilot (dev): the unbiased group-mean masked estimator ("MaskRocket") is much WORSE than linear interpolation +
   MiniRocket on ArrowHead under MCAR (0.697 vs 0.857 at 30%). Hypothesis: high variance and loss of temporal smoothness.
2. Confidence-weighted pooling on interpolated input ("WRocket", weight = (observed taps/9)^gamma) is also worse than
   plain interpolation, and monotonically worse as gamma increases (dev, first 6 settings).
3. The LightGBM baseline was initially degenerate on small training sets (min_child_samples=20 gave majority-class
   predictions). Fixed (min_child_samples=5) before any confirmatory run; dev rows rerun.
4. Dev screening, 8 datasets × 6 settings: dilation-aware hybrid "GapRocket" is worse than interpolation (0.760 vs 0.789 on the
   first 5 datasets). Hypothesis H-gap rejected.
5. Dev: feature fusion (interpolated ‖ group-mean) gives no gain over a feature-matched 20k control (23 W / 22 L). Rejected.
6. Dev finding: regime dependence. Observed-tap-weighted pooling (gamma=1) beats interpolation under block missingness
   (+1.6/+2.4 pts at 30/60%) but loses under MCAR (−1.8/−3.7 pts). This motivates the FINAL METHOD, MissRocket:
   interpolation + observed-tap-weighted PPV with gamma∈{0,.5,1,2} × mask-features∈{off,on} selected on TRAIN by the
   ridge LOO (GCV) score. gamma=0 is exactly interpolation+MiniRocket. Next step: dev screening of MissRocket,
   then freeze the protocol.
7. INTEGRITY ISSUE FOUND AND FIXED. The dev rows for WRocket-noC (and possibly other variants) generated 2026-11-10 22:03–22:14
   do not match the current code. The current code gives identical features for WRocket-noC and MissRocket-g1 (max
   diff 3.6e-7), yet the stored accuracies differ systematically (e.g. ArrowHead MCAR +0.09). Cause: rows produced by
   different intermediate code versions during optimisation, possibly worsened by numba's cache not tracking
   cross-file njit changes. Remedy: (a) all experiment entry points clear numba caches before running; (b) the full dev
   screening is redone under one frozen code version in results/dev/dev_screening_v2.csv. Earlier dev conclusions
   (items 1–6) are provisional until then. The old file is retained as results/dev/dev_viability_STALE.csv.
8. Dev screening v2 (frozen code, 8 dev datasets × 48 settings): fixed gamma=1 weighting is best (mean acc 0.8213, rank 4.39)
   vs interpolation + MiniRocket (0.8108 own / 0.8093 aeon); LOO selection 0.8187; native estimators 0.75–0.79.
   DECISION: primary method = MissRocket with gamma=1, no mask (selection, other gammas, mask and gap filler become ablations).
9. PROTOCOL SLIP (disclosed): the first quick-mode pipeline check ran on 3 CONFIRMATORY datasets (Coffee,
   ItalyPowerDemand, SyntheticControl). Results there showed kNN imputation as a strong baseline. Quick mode now uses
   dev datasets only. kNN gap filling had not been screened, so it is screened ON THE DEV SET ONLY
   (results/dev/dev_screening_v2.csv) before freezing.
10. Dev kNN screening: kNN filling helps under block 60% but hurts under MCAR 60%; weighting adds nothing on kNN fills.
    Overall linear + gamma=1 is still best (0.8213 vs 0.8136/0.8143). Primary method unchanged; kNN variants added to E3.
11. PROTOCOL FROZEN at the commit titled "PROTOCOL FREEZE". Confirmatory runs (E1–E7) start after it with this code and config.

## Confirmatory runs (started 2026-11-11 03:17 UTC)
- E1 runs in the background: `cd Target_Journal_Submission/code && nohup python3 run_all.py --mode full --only E1 > logs/full_E1.log 2>&1 &`
- `scripts/chain_full.sh` waits for E1, then runs `run_all.py --mode full`, which covers E3, E5a, E5b, E4, E7, E2, the analysis,
  the method figures and the E8 error analysis.
- Estimated time: E1 ≈ 14 h; the rest ≈ 10 h.
- **If the container restarted**, background jobs are gone. Restart with:
  `cd Target_Journal_Submission/code && nohup python3 run_all.py --mode full > logs/full_all.log 2>&1 &`
  All experiments are resumable and skip finished rows.
- Check progress with: `tail -1 logs/full_E1.log logs/full_all.log; wc -l results/full/*/raw_results.csv`
- After the runs: build the manuscript (manuscript/source/*.md with {{placeholders}} filled from results/full/statistics),
  then 10 review rounds, DOCX/PDF, cover letter, final package.
12. INFRASTRUCTURE: the container is reclaimed a few minutes after the session goes idle. This killed the nohup E1 run at
    03:35 UTC, about 4 h of wall time lost; results were safe because the runner resumes. From 07:42 UTC the experiments run as
    harness-tracked background tasks in ≤2 h chunks (`timeout 7000 python3 run_all.py --mode full`), and the session
    stays active while they run.
13. EXECUTION-ORDER AMENDMENT (08:05 UTC, results-blind: only timing and status inspected). E1 seeds 0–1 run first, then
    E3, E5a, E5b, E4, E7 and E2, then E1 seed 2 last (same results file). Analyses use every completed seed. If seed 2 does
    not complete, the paper reports 2 seeds and states the deviation.
14. INFRASTRUCTURE FAILURE #2 + AMENDMENT 2 (2026-11-12 05:40 UTC, results-blind: no accuracy inspected).
    My turn ended after a wait call; the idle container was reclaimed and E1 stopped at 3,765 rows (seed 0 ≈ 38%).
    About 21 h of wall time were lost; files are intact.
    Rescope:
    - E1 primary = seed 0 on all 91 eligible datasets.
    - Seeds 1–2 only on a pre-declared random 30-dataset subset (RandomState(11)), run last.
    - E3 (rate 0.5) and E4 run on the same subset.
    - P12 uses seed 0 + patient-level bootstrap.
    - E2 restricted to length ≤ 200 and n_train ≤ 300.
    - Order: E1 → E5a → E3 → E4 → E5b → E7 → E2 → E1 seeds 1–2.
    Primary analyses use E1 seed 0. Rule from now on: never end a turn while compute runs; commit results about every 30 min.
15. ANALYSIS ERROR FOUND IN REVIEW 3 AND FIXED: the error-analysis correlations had pooled the 3 rates per mechanism (n=273),
    counting each dataset 3 times (pseudo-replication). The strong 'gain grows with gap length' associations were a
    between-rate confound. The per-rate analysis (n=91) shows significant associations only at block 80%. Manuscript
    claims were rewritten accordingly (Sect. 6.8, 7.1, 7.4).

16. REVIEW ROUNDS 1–10 complete. Main fixes:
    - "pre-registered" → "pre-specified";
    - amendments disclosed;
    - pseudo-replication in the error analysis fixed;
    - 16 overstatements corrected;
    - literature paraphrases corrected against primary sources;
    - mechanism-shift experiment E4b added (post hoc);
    - controlled scaling benchmark added.
    Reproducibility: 24/24 sampled runs re-executed with exact equality; fresh quick mode passes.

## Revision after external (professor) review — 2026-11-18
17. New industrial case study E9 (CWRU bearing vibration; sensor dropouts), requested by the reviewer. The design was
    written to config/experiments.yaml BEFORE running:
    - data: 10 classes; leave-one-load-out folds; normal files decimated 48→12 kHz;
    - 13 conditions: complete; random 10/30/50%; outages short/medium/long at 30%; long at 50%;
      train-complete → test-incomplete shifts;
    - 7 methods; seeds 0,1 for the core 3 methods and seed 0 for the others.
    DISCLOSURE: a timing test of one setting (fold 3, medium outages 30%, seed-1/2 masks) printed accuracies before this
    commit; the design was not changed afterwards. The E9 freeze is the commit titled "E9 DESIGN FREEZE".
18. E9 completed (520 runs, all ok). Edge-CPU proxy benchmark (scripts/benchmark_edge.py, one thread, idle machine) and
    confusion diagnostic (scripts/e9_confusion.py) run afterwards. The diagnostic reproduced all 24 stored accuracies exactly.
    CORRECTION: a draft of Section 6.10 said that interpolation-based MiniRocket misclassified faults mostly as "normal". The
    confusion matrices contradict this: under long-outage shift it put 41% and 28% of all predictions in two fault classes
    (IR014, B014), misdiagnosed 64% of fault segments as another fault, and called 9% of fault segments normal (MissRocket: 0%).
    The text was corrected before submission. Also corrected: the draft claimed latencies of "a few ms" for all methods;
    measured single-thread latency is 2.8 ms (aeon MiniRocket), 46 ms (MissRocket) and 59 ms (Hydra-MultiRocket).

